import { Component, OnInit, OnDestroy } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { SubmissionsService } from './submission.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [SubmissionsService],
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'app';
  getcctoapsdetailsData: any;
  proposalId: any;
  connectionTypeSection: string = 'Connection Type - Control and Single Risk';
  constructor(private http: HttpClient, private _submissionService: SubmissionsService) { }

  ngOnInit(): void {
    this._submissionService.getAuthors();

    this._submissionService.getcctoapsdetails(this.proposalId).subscribe(data => {
      console.log(JSON.stringify(data, null, 4));
      this.getcctoapsdetailsData = data;
    });
  }

  ngOnDestroy() {

  }
}