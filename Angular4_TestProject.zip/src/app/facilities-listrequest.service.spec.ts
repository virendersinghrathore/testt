import { TestBed, inject } from '@angular/core/testing';

import { FacilitiesListrequestService } from './facilities-listrequest.service';

describe('FacilitiesListrequestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FacilitiesListrequestService]
    });
  });

  it('should be created', inject([FacilitiesListrequestService], (service: FacilitiesListrequestService) => {
    expect(service).toBeTruthy();
  }));
});
