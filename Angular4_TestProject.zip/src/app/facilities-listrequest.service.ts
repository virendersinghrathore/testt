import { Injectable } from '@angular/core';

@Injectable()
export class FacilitiesListrequestService {

  constructor() { }

}
