import { Injectable, Inject, EventEmitter, Output, OnInit, OnDestroy } from '@angular/core';
import { Http } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
@Injectable()

export class SubmissionsService {
  proposalId;
  subRefData = new Subject<any>();
  newDdepExposurelData = new BehaviorSubject<any>({});
  onRefreshData: boolean;
  aggregatedGroupModal: any;
  proposalSubmissionStatus: any;
  aggregatedResponseDB: any;
  fetchedDdepDeatails: any;
  counterPartyId: any;
  counterPartyIdScheme: any;
  ddepExposureReady: boolean;
  ddepErrorValue: boolean;
  aggregatedGroupModalfake = [
    {
      name: 'SRAE',
      labelText: 'Group Aggregated SRAE',
      labelValue: 'N/A',
    },
    {
      name: 'TAE',
      labelText: 'Group Aggregated TAE',
      labelValue: 'N/A'
    },
    {
      name: 'TUAE',
      labelText: 'Group Aggregated TUAE',
      labelValue: 'N/A',
    }
  ];
  // urls
  ExposureFromDbUrl: string = 'http://www.mocky.io/v2/5e0e3b49330000cdd9aa8a8e';
  ExposureDDEPAPICall: string = '';
  ExposureStoreIntoDB: string = '';
  @Output() valueChange = new EventEmitter();
  ddepParameters: string;
  customError: string;
  ddepAPiResponse: any;
  statusCode400 = 400;
  statusCode404 = 404;
  statusCode500 = 500;
  errorResponseArray: any;
  tAETotal: any;
  errorDdepCode: any;
  errorDdepMessgae: any;
  errorDdepDescription: any;
  tUAETotal: any;
  sRAETotal: any;
  timestamp: any;
  processedDateTime: any;
  valueChanged() {
    this.valueChange.emit();
  }

  constructor(private http: Http) { }
  getAuthors() {
    return this.http.get(this.ExposureFromDbUrl);
  }
  getConnectionTypeDdepExposure(ddepParameters: any) {
    return this.http.get('' + ddepParameters);
  }
  getcctoapsdetails(data) {
    this.proposalId = data;
    return this.http.get('http://localhost:3000/getcctoapsdetails');
  }
  getDdepAPIResponse(params, proposal_id) {
    const temp_proposalID = proposal_id;
    console.log('called service getDdepAPIResponse :: ');
    this.counterPartyId = params.counterpartyIdentifier;
    this.counterPartyIdScheme = params.counterpartyIdentifierScheme;
    if (this.counterPartyId !== undefined && this.counterPartyIdScheme !== undefined) {
      this.ddepParameters = 'counterPartyId=' + this.counterPartyId + '&counterPartyIdScheme=' + this.counterPartyIdScheme + '&businessUnit=WWIB&brandSilo=WPAC';
      this.getConnectionTypeDdepExposure(this.ddepParameters).subscribe(data => {
        //let statusCodeValue = data.statusCodeValue;
        let statusCodeValue = data.status;
        if (statusCodeValue === undefined) {
          console.log('status code as undefined value found ::' + statusCodeValue + 'counterPartyIdScheme is :: ' + this.counterPartyIdScheme);
          if ((statusCodeValue === 400)) {
            alert('400 Error');
            this.customError = 'No data found. Failed to refresh latest exposures.';
            this.storeDdepErrorInDatabase(data);
          } else if (statusCodeValue === 404) {
            alert('404 Error');
            this.customError = 'No data found. Failed to refresh latest exposures.';
            this.storeDdepErrorInDatabase(data);
          } else if (statusCodeValue === 500) {
            alert('500 Error');
            this.customError = 'Technical error. Failed to refresh latest exposures.';
            this.storeDdepErrorInDatabase(data);
          } else {
            alert('unknown Error');
            this.customError = 'Unknown error. Failed to refresh latest exposures.';
            this.callDatabaseToFetchDdepExposureData(temp_proposalID);
          }
        } else {
          console.log('status code value ::' + statusCodeValue + 'counterPartyIdScheme is :: ' + this.counterPartyIdScheme);
          if (statusCodeValue === 200) {
            //this.ddepAPiResponse = data.body.data;
            this.ddepAPiResponse = data;
            this.groupAggregatedExposuredata(this.ddepAPiResponse);
          }
        }
        return;
      });
    }
  }
  callDatabaseToFetchDdepExposureData(temp_proposalID: any) {
    throw new Error('Method not implemented.');
  }
  groupAggregatedExposuredata(ddepAPiResponse: any) {
    throw new Error('Method not implemented.');
  }
  storeDdepErrorInDatabase(error) {
    this.errorResponseArray = error.substring(3, error.length - 0);
    const json = JSON.parse(this.errorResponseArray);
    if (json !== undefined && json.length > 0) {
      this.ddepErrorResponseCode(json.result);
    }
  }

  ddepErrorResponseCode(error) {

    if (error !== undefined) {
      this.setrefreshDate();
      this.errorDdepCode = error.errors[0].code;
      this.errorDdepMessgae = error.errors[0].message;
      this.errorDdepDescription = error.errors[0].details;

      const groupExposureInsertErrorObject = {
        'proposalID': this.proposalId,
        'tae': this.tAETotal,
        'tuae': this.tUAETotal,
        'srae': this.sRAETotal,
        'currency': 25,
        'refreshDate': this.timestamp,
        'exceptionDate': this.timestamp,
        'dataDate': this.processedDateTime,
        'errorCode': this.errorDdepCode,
        'errorMessage': this.errorDdepMessgae,
        'errorDescription': this.errorDdepDescription
      };
      this.insertConnectedPartyProposalDetails(groupExposureInsertErrorObject).subscribe(() => {
      });
    }
  }
  setrefreshDate() {
    throw new Error("Method not implemented.");
  }
  insertConnectedPartyProposalDetails(data) {

    return this.http.put('abc', data);

  }
}

